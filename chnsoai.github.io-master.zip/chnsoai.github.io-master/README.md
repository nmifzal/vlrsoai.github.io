# chnsoai.github.io
Official website of Chennai School of AI
